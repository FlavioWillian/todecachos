<?php
// This file was auto-generated from sdk-root/src/data/cloudcontrol/2021-09-30/paginators-1.json
return [ 'pagination' => [ 'ListResourceRequests' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'ResourceRequestStatusSummaries', ], 'ListResources' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'ResourceDescriptions', ], ],];
